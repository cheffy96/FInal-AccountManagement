package com.cg.ibs.accountmanagement.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.model.Beneficiary;
import com.cg.ibs.accountmanagement.model.Customer;

public interface CustomerService {
	public boolean validateCustomer(String userId) throws IBSException;
	public Customer customerByUserId(String userId) ;
	public List<Beneficiary> getBeneficiary(BigInteger uci);
	public Beneficiary selectBeneficiary(BigInteger accNo);

}
