package com.cg.ibs.accountmanagement.model;

public enum Gender {
	PREFER_NOT_TO_SAY, MALE, FEMALE;
}
