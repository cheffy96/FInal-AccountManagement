package com.cg.ibs.accountmanagement.model;

public enum AccountHoldingType {
	PRIMARY, SECONDARY, INDIVIDUAL;
}
