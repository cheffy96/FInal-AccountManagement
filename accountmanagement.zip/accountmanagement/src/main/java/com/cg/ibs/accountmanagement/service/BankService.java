package com.cg.ibs.accountmanagement.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.model.TransactionBean;

public interface BankService {
	public boolean validateBanker(String bankId) throws IBSException;
	public void fundsDeposit(BigInteger accNo,BigDecimal amt) throws IBSException;
	public List<TransactionBean> periodicTransactions(LocalDateTime startDate,LocalDateTime endDate,BigInteger accNo) throws IBSException;
	public String getCustomerName( BigInteger accNo);
}
