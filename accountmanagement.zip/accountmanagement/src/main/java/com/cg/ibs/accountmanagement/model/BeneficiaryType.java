package com.cg.ibs.accountmanagement.model;



 

public enum BeneficiaryType {
    MY_ACCOUNT_IN_IBS, MY_ACCOUNT_IN_OTHER_BANKS, OTHERS_ACCOUNT_IN_IBS, OTHERS_ACCOUNT_IN_OTHER_BANKS
}