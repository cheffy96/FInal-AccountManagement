package com.cg.ibs.accountmanagement.model;

public enum TransactionMode {
	ONLINE, CASH;
}
