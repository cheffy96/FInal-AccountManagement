package com.cg.ibs.accountmanagement.service;

import java.math.BigInteger;
import java.util.List;

//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.accountmanagement.dao.CustomerDao;
import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.exception.IBSExceptionInt;
import com.cg.ibs.accountmanagement.model.Beneficiary;
import com.cg.ibs.accountmanagement.model.Customer;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	
	//private static Logger logger = Logger.getLogger(CustomerServiceImpl.class);
	
	@Autowired
	private CustomerDao customerDao;
	
	//EntityTransaction entityTransaction;

	@Override
	public boolean validateCustomer(String userId) throws IBSException {
		boolean flag = false;
		Customer customerBean = customerDao.getCustomerByUserId(userId);
		if (customerBean != null) {
				flag = true;
		} else {
			//logger.error(IBSExceptionInt.WRONG_UID_AND_PASSWORD);
			throw new IBSException(IBSExceptionInt.WRONG_UID_AND_PASSWORD);
		}
		//logger.info("Validated customer returned");
		return flag;
	}

	@Override
	public Customer customerByUserId(String userId)  {
		return customerDao.getCustomerByUserId(userId);
	}

	@Override
	public List<Beneficiary> getBeneficiary(BigInteger uci) {
		return customerDao.getBeneficiary(uci);
	}

	@Override
	public Beneficiary selectBeneficiary(BigInteger accNo) {
		return customerDao.beneficiary(accNo);
	}
}
