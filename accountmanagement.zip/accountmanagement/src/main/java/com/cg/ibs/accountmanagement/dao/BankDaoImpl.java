package com.cg.ibs.accountmanagement.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

//import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.exception.IBSExceptionInt;
import com.cg.ibs.accountmanagement.model.BankAdmin;


@Repository("bankDao")
public class BankDaoImpl implements BankDao {

	//private static Logger logger = Logger.getLogger(BankDaoImpl.class);
@PersistenceContext
	private EntityManager entityManager;
	
//	public BankDaoImpl() {
//		entityManager= DBUtil.getEntityManger();
//	}

	@Override
	public BankAdmin getByAdminId(String admin_id) throws IBSException {
		BankAdmin bankBean = null;
		bankBean = entityManager.find(BankAdmin.class, admin_id);
		if (bankBean == null) {
			//logger.error(IBSExceptionInt.WRONG_BANKERID_AND_PASSWORD);
			throw new IBSException(IBSExceptionInt.WRONG_BANKERID_AND_PASSWORD);
		}
		//logger.info(" Details of bank admin returned");
		return bankBean;
	}
	
	@Override
	public String getCustomerName(BigInteger accNo) {
		TypedQuery<String> query= entityManager.createNamedQuery("NAME_CUSTOMER", String.class);
		query.setParameter("accNo", accNo);
		String name= query.getSingleResult();
		return name;
	}
}
