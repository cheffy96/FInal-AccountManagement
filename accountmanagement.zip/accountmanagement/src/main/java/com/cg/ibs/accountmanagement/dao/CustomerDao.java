package com.cg.ibs.accountmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.accountmanagement.model.Beneficiary;
import com.cg.ibs.accountmanagement.model.Customer;

public interface CustomerDao {
	public Customer getCustomerByUCI(BigInteger UCI);
	public Customer getCustomerByUserId(String userId);
	public List<Beneficiary> getBeneficiary(BigInteger uci);
	public Beneficiary beneficiary(BigInteger accno);
}
