package com.cg.ibs.accountmanagement.model;

public enum TransactionType {
	CREDIT, DEBIT;
}
