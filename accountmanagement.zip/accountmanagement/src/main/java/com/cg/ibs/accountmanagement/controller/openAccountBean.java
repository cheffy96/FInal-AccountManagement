package com.cg.ibs.accountmanagement.controller;

import java.math.BigInteger;

import com.cg.ibs.accountmanagement.model.AccountType;

public class openAccountBean {

//	@RequestParam("accountType") AccountType accountType,
//	@RequestParam("accNo") BigInteger accNo, @RequestParam("amount") double amount,
//	@RequestParam("tenure") double tenure
	
	private AccountType acctype;
	private BigInteger accNo;
	private double amt;
	private double tenure;
	private String userId;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public AccountType getAcctype() {
		return acctype;
	}
	public void setAcctype(AccountType acctype) {
		this.acctype = acctype;
	}
	public BigInteger getAccNo() {
		return accNo;
	}
	public void setAccNo(BigInteger accNo) {
		this.accNo = accNo;
	}
	public double getAmt() {
		return amt;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}
	public double getTenure() {
		return tenure;
	}
	public void setTenure(double tenure) {
		this.tenure = tenure;
	}
	
	
}
