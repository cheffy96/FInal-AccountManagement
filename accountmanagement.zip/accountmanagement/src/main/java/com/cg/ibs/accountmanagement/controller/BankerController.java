package com.cg.ibs.accountmanagement.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.model.Account;
import com.cg.ibs.accountmanagement.model.TransactionBean;
import com.cg.ibs.accountmanagement.service.AccountService;
import com.cg.ibs.accountmanagement.service.BankService;

@RestController
@RequestMapping("/banker")
@Scope("session")
@CrossOrigin
public class BankerController {
	@Autowired
	private BankService bankService;

	@Autowired
	private AccountService accountService;


	@GetMapping("/bankerlogin/{adminId}")
	public ResponseEntity<String> checkUser(@PathVariable("adminId") String userId) {
		ResponseEntity<String> result;
		String msg;
		boolean flag = false;
		if (userId == null) {
			msg="No User Details Received";
			result = new ResponseEntity<>(msg, HttpStatus.BAD_REQUEST);
		}
		else {
		try {
			flag = bankService.validateBanker(userId);
		} catch (IBSException excp) {

		}
		if (flag == true) {
			msg="Hello " + userId;
			result= new ResponseEntity<String>(msg,HttpStatus.OK);
			//mv.addObject("res", ("Welcome to IBS," + userId));
			//mv.setViewName("welcomeBanker");
		} else {
			//mv.addObject("res", "Invalid UserId and Password");
			//mv.setViewName("invalidBanker");
			msg="Invalid Bank UserId";
			result= new ResponseEntity<String>(msg,HttpStatus.UNAUTHORIZED);
		}
		}
		return result;
	}

//	@RequestMapping("/fundsDeposit")
//	public ModelAndView fundsDeposit() {
//		ModelAndView mView = new ModelAndView("/fundsDeposit");
//		return mView;
//	}

//	@RequestMapping("/accountFunds")
//	public ModelAndView accountFunds(@RequestParam("accountNum") BigInteger accNumber) {
//		Account account = new Account();
//		String message = "Account Details:";
//
//		ModelAndView view = new ModelAndView("/depositAmount");
//		try {
//			account = accountService.viewAccount(accNumber);
//
//		} catch (Exception e) {
//			String message1 = e.getMessage();
//			view.addObject("res", message1);
//		}
//		String name = bankService.getCustomerName(accNumber);
//		view.addObject("name", name);
//		List<Account> accounts = new ArrayList<Account>();
//		accounts.add(account);
//		view.addObject("accountNum", account.getAccNo());
//		view.addObject("list", accounts);
//		view.addObject("res", message);
//		return view;
//	}

	@GetMapping("/getAccount/{accNo}")
	public ResponseEntity<?> getAccountDetails(@PathVariable("accNo") BigInteger accountNum){
		ResponseEntity<?> result= null;
		String customer= bankService.getCustomerName(accountNum);
		try {
			Account account= accountService.viewAccount(accountNum);
			Map<String, Account> accountMap= new HashMap<String, Account>();
			accountMap.put(customer, account);
			result= new ResponseEntity<Map<String,Account>>(accountMap, HttpStatus.OK);
		} catch (IBSException e) {
			String msg=e.getMessage();
			result= new ResponseEntity<String>(msg,HttpStatus.UNAUTHORIZED);
		}
		
		return result;
	}
	
	@GetMapping("/depositDone/{amount}/{accNo}")
	public ResponseEntity<String> depositDone(@PathVariable("amount") BigDecimal amount,
			@PathVariable("accNo") BigInteger accountNo) {
		BigDecimal balance = BigDecimal.valueOf(0);
		ResponseEntity<String> result=null;
		boolean flag=accountService.checkAccountExists(accountNo);
		if(flag==false)
		{
			result= new ResponseEntity<String>("No Account exists with this accountNumber",HttpStatus.UNAUTHORIZED);
		}
		else {
		try {
			bankService.fundsDeposit(accountNo, amount);
			balance = accountService.getBalance(accountNo);
			result= new ResponseEntity<String>("Transfer Funds successful.. Balance in account is: "+balance,HttpStatus.OK);
		} catch (IBSException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			String msg=e.getMessage();
			result= new ResponseEntity<String>(msg,HttpStatus.UNAUTHORIZED);
		}
		}
		return result;
	}

//	@RequestMapping("/periodicStatement")
//	public ModelAndView getPeriodicStatement() {
//		ModelAndView view = new ModelAndView("/periodicBanker");
//		return view;
//	}

//	@RequestMapping("/periodicFinal")
//	public ModelAndView generateStatement(@RequestParam("accountNum") BigInteger accountNum,
//			@RequestParam("start") String startDate, @RequestParam("end") String endDate) {
//		ModelAndView periodicView = new ModelAndView();
//		DateTimeFormatter dtFormat=  DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a");
//		List<TransactionBean> txns = new ArrayList<TransactionBean>();
//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH:mm:ss");
//		startDate = startDate + "-00:00:00";
//		LocalDateTime startDate1 = LocalDateTime.parse(startDate, formatter);
//		endDate = endDate + "-23:59:59";
//		LocalDateTime endDate1 = LocalDateTime.parse(endDate, formatter);
//		long noOfDaysBetween = ChronoUnit.DAYS.between(startDate1, endDate1);
//		int months = (int) (noOfDaysBetween / 30);
//
//		if (startDate1.compareTo(LocalDateTime.now()) > 0 || startDate1.compareTo(endDate1) > 0 || months > 6) {
//			periodicView.addObject("res", "Enter Proper Dates");
//			periodicView.setViewName("periodicError");
//
//		} else {
//			try {
//				txns = bankService.periodicTransactions(startDate1, endDate1, accountNum);
//			} catch (IBSException e) {
//				// TODO Auto-generated catch block
//				// e.printStackTrace();
//			}
//			periodicView.addObject("list", txns);
//			periodicView.addObject("dtFormat", dtFormat);
//			periodicView.setViewName("periodicStatement");
//			
//		}
//		return periodicView;
//	}
	
	
	@GetMapping("/periodicFinal/{accNo}/{startDate}/{endDate}")
	public ResponseEntity<List<TransactionBean>> periodicStatements(@PathVariable("accNo") BigInteger accNo,
			@PathVariable("startDate") String start, @PathVariable("endDate") String end) {
		ResponseEntity<List<TransactionBean>> result = null;
		List<TransactionBean> txns = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH:mm:ss");
		String start1 = start;
		String end1 = end;
		start = start + "-00:00:00";
		LocalDateTime startDate1 = LocalDateTime.parse(start, formatter);
		end = end + "-23:59:59";
		LocalDateTime endDate1 = LocalDateTime.parse(end, formatter);
		long noOfDaysBetween = ChronoUnit.DAYS.between(startDate1, endDate1);
		int months = (int) (noOfDaysBetween / 30);
		DateTimeFormatter dtFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a");
		try {
			txns = bankService.periodicTransactions(startDate1, endDate1, accNo);
			result = new ResponseEntity<List<TransactionBean>>(txns, HttpStatus.OK);
		} catch (IBSException e) {
			String message = e.getMessage();
			result = new ResponseEntity<List<TransactionBean>>(txns, HttpStatus.UNAUTHORIZED);
		}
		return result;
	}
	
	
	@GetMapping("/checkBalanceBanker/{accNo}")
	public ResponseEntity<String> balanceBanker(@PathVariable("accNo") BigInteger accNo) {
		BigDecimal bal = new BigDecimal(0);
		ResponseEntity<String> result = null;
		if (accNo == null) {
			result = new ResponseEntity<>("No User Details Received", HttpStatus.BAD_REQUEST);
		} else {
			try {
				bal = accountService.getBalance(accNo);
				bal = bal.setScale(2, BigDecimal.ROUND_HALF_UP);
				result = new ResponseEntity<String>("Balance is: " + bal.toString(), HttpStatus.OK);
			} catch (IBSException e) {
				String message = e.getMessage();
				result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
				// mv.addObject("message", message);
				// mv.setViewName("showMessage");
			}
		}
		return result;
	}

}
