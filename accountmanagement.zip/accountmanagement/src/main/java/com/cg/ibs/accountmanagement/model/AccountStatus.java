package com.cg.ibs.accountmanagement.model;

public enum AccountStatus {
	ACTIVE, CLOSED;
}
