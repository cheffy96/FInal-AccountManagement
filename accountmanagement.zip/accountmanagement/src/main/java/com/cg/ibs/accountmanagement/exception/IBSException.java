package com.cg.ibs.accountmanagement.exception;

public class IBSException extends Exception implements IBSExceptionInt {
	public IBSException(String message) {
		super(message);
	}
}
