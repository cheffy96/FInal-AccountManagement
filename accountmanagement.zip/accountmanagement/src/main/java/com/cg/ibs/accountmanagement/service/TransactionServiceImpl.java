package com.cg.ibs.accountmanagement.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.persistence.EntityTransaction;
import javax.transaction.Transactional;

//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.accountmanagement.dao.AccountDao;
import com.cg.ibs.accountmanagement.dao.TransactionDao;
import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.exception.IBSExceptionInt;
import com.cg.ibs.accountmanagement.model.Account;
import com.cg.ibs.accountmanagement.model.AccountStatus;
import com.cg.ibs.accountmanagement.model.ServiceProvider;
import com.cg.ibs.accountmanagement.model.TransactionBean;
import com.cg.ibs.accountmanagement.model.TransactionMode;
import com.cg.ibs.accountmanagement.model.TransactionType;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private AccountDao accountDao;

	@Override
	public List<TransactionBean> getMiniStmt(BigInteger accNo) {
		List<TransactionBean> transList = null;
		transList = transactionDao.getMiniTransactions(accNo);
		// logger.info(" Mini statement fetched");
		return transList;
	}

	@Override
	public List<TransactionBean> getPeriodicStmt(LocalDateTime startDate, LocalDateTime endDate, BigInteger accNo)
			throws IBSException {
		// entityTransaction=DBUtil.getTransaction();
		List<TransactionBean> transList = null;
		LocalDate startDate1 = startDate.toLocalDate();
		LocalDate endDate1 = endDate.toLocalDate();

		long noOfDaysBetween = ChronoUnit.DAYS.between(startDate1, endDate1);
		int months = (int) (noOfDaysBetween / 30);
		if (startDate.compareTo(endDate) < 0 && months <= 6 && startDate.compareTo(LocalDateTime.now()) < 0) {
			transList = transactionDao.getPeriodicTransactions(startDate, endDate, accNo);
			// logger.info(" Periodic statement fetched");
		} else {
			throw new IBSException(IBSExceptionInt.INVALID_PERIOD);
		}
		return transList;
	}

	@Override
	@Transactional
	public BigDecimal TransferFunds(BigInteger accNo, BigDecimal amt, String tranPwd, BigInteger recipientNo)
			throws IBSException {
		// entityTransaction= DBUtil.getTransaction();
		LocalDateTime todayDate = LocalDateTime.now();
		Account accountBean = accountDao.getAccountByAccNo(accNo);
		BigDecimal currentBal = accountBean.getBalance();
		int refId;
		if (accountBean.getAccStatus().equals(AccountStatus.CLOSED)) {
			// logger.error(IBSExceptionInt.ACCOUNT_CLOSED);
			throw new IBSException(IBSExceptionInt.ACCOUNT_CLOSED);
		} else if (currentBal.compareTo(amt) < 0 || amt.compareTo(new BigDecimal(0)) <= 0) {
			// logger.error(IBSExceptionInt.BALANCE_ERROR_MESSAGE);
			throw new IBSException(IBSExceptionInt.BALANCE_ERROR_MESSAGE);
		} else {
			if (tranPwd.equals(accountBean.getTrans_Pwd())) {
				accountBean.setBalance(accountBean.getBalance().subtract(amt));
				TransactionBean t1 = new TransactionBean();
				t1.setAccount(accountBean);
				t1.setTransactionAmount(amt);
				t1.setTransactionDate(todayDate);
				t1.setTransactionDescription("Online transfer to " + recipientNo.toString());
				t1.setTransactionMode(TransactionMode.ONLINE);
				t1.setTransactionType(TransactionType.DEBIT);
				t1.setCurrentBalance(accountBean.getBalance());
				transactionDao.addNewTransaction(t1);
				// accountDao.update(accountBean);
				// accountBean.getTransaction().add(t1);
				refId = fundsDeposit(recipientNo, amt, accNo, t1.getTransactionId());
				t1.setReferenceId(String.valueOf(refId));

				accountDao.update(accountBean);
			} else {
				// logger.error(IBSExceptionInt.INVALID_TRANS_PASSW);
				throw new IBSException(IBSExceptionInt.INVALID_TRANS_PASSW);
			}
		}
		// logger.info(" Funds transferred succesfully");
		return accountBean.getBalance();
	}

	public BigDecimal payBill(BigInteger accNo, BigDecimal amt, String tranPwd, BigInteger recipientNo)
			throws IBSException {
		// entityTransaction= DBUtil.getTransaction();
		LocalDateTime todayDate = LocalDateTime.now();
		Account accountBean = accountDao.getAccountByAccNo(accNo);
		BigDecimal currentBal = accountBean.getBalance();

		if (accountBean.getAccStatus().equals(AccountStatus.CLOSED)) {
			// logger.error(IBSExceptionInt.ACCOUNT_CLOSED);
			throw new IBSException(IBSExceptionInt.ACCOUNT_CLOSED);
		} else if (currentBal.compareTo(amt) < 0 || amt.compareTo(new BigDecimal(0)) <= 0) {
			// logger.error(IBSExceptionInt.BALANCE_ERROR_MESSAGE);
			throw new IBSException(IBSExceptionInt.BALANCE_ERROR_MESSAGE);
		} else {
			if (tranPwd.equals(accountBean.getTrans_Pwd())) {
				accountBean.setBalance(accountBean.getBalance().subtract(amt));
				TransactionBean t1 = new TransactionBean();
				t1.setAccount(accountBean);
				t1.setTransactionAmount(amt);
				t1.setTransactionDate(todayDate);
				t1.setTransactionDescription("Online transfer to " + recipientNo.toString());
				t1.setTransactionMode(TransactionMode.ONLINE);
				t1.setTransactionType(TransactionType.DEBIT);
				t1.setReferenceId("Pay utility bills");
				t1.setCurrentBalance(accountBean.getBalance());
				transactionDao.addNewTransaction(t1);
				accountDao.update(accountBean);
			} else {
				// logger.error(IBSExceptionInt.INVALID_TRANS_PASSW);
				throw new IBSException(IBSExceptionInt.INVALID_TRANS_PASSW);
			}
		}
		// logger.info(" Funds transferred succesfully");
		return accountBean.getBalance();
	}

	@Override
	@Transactional
	public int fundsDeposit(BigInteger accNo, BigDecimal amt, BigInteger transferAccount, int transId)
			throws IBSException {
		// entityTransaction= DBUtil.getTransaction();
		Account accountBean = accountDao.getAccountByAccNo(accNo);
		TransactionBean tranBean = new TransactionBean();
		if (accountBean != null && accountBean.getAccStatus().equals(AccountStatus.ACTIVE)) {
			accountBean.setBalance(accountBean.getBalance().add(amt));
			tranBean.setAccount(accountBean);
			tranBean.setTransactionAmount(amt);
			tranBean.setTransactionDate(LocalDateTime.now());
			tranBean.setTransactionType(TransactionType.CREDIT);
			tranBean.setTransactionMode(TransactionMode.ONLINE);
			tranBean.setTransactionDescription(" Pay UtilityBills");
			tranBean.setReferenceId(String.valueOf(transId));
			tranBean.setCurrentBalance(accountBean.getBalance());
			// if(!entityTransaction.isActive()) {
			// entityTransaction.begin();
			// }
			//
			accountDao.update(accountBean);
			transactionDao.addNewTransaction(tranBean);
			// entityTransaction.commit();
		} else {
			// logger.error(IBSExceptionInt.INVALID_ACC_NO);
			throw new IBSException(IBSExceptionInt.INVALID_ACC_NO);
		}
		return tranBean.getTransactionId();
	}

	@Override
	@Transactional
	public BigDecimal payUtilityBill(BigInteger accNo, BigInteger recipientNo, String transacPass, BigDecimal amount)
			throws IBSException {
		BigDecimal balance = payBill(accNo, amount, transacPass, recipientNo);
		// logger.info(" Utility bill paid");
		return balance;
	}

	@Override
	public List<ServiceProvider> getServiceProviders() {
		List<ServiceProvider> spList = transactionDao.getServiceProviders();
		// logger.info(" Service providers list displayed");
		return spList;
	}

	@Transactional
	@Override
	public BigDecimal TransferFundsOtherBank(BigInteger accNo, BigDecimal amt, String tranPwd, BigInteger recipientNo,
			String otherBank) throws IBSException {
		// entityTransaction= DBUtil.getTransaction();
		LocalDateTime todayDate = LocalDateTime.now();
		Account accountBean = accountDao.getAccountByAccNo(accNo);
		BigDecimal currentBal = accountBean.getBalance();
		if (accountBean.getAccStatus().equals(AccountStatus.CLOSED)) {
			// logger.error(IBSExceptionInt.ACCOUNT_CLOSED);
			throw new IBSException(IBSExceptionInt.ACCOUNT_CLOSED);
		} else if (currentBal.compareTo(amt) < 0 || amt.compareTo(new BigDecimal(0)) <= 0) {
			// logger.error(IBSExceptionInt.BALANCE_ERROR_MESSAGE);
			throw new IBSException(IBSExceptionInt.BALANCE_ERROR_MESSAGE);
		} else {
			if (tranPwd.equals(accountBean.getTrans_Pwd())) {
				accountBean.setBalance(accountBean.getBalance().subtract(amt));
				TransactionBean t1 = new TransactionBean();
				t1.setAccount(accountBean);
				t1.setTransactionAmount(amt);
				t1.setTransactionDate(todayDate);
				t1.setTransactionDescription("Online transfer to " + recipientNo.toString());
				t1.setTransactionMode(TransactionMode.ONLINE);
				t1.setTransactionType(TransactionType.DEBIT);
				t1.setReferenceId("#" + otherBank + "/" + recipientNo.toString() + "/" + todayDate.toString());
				t1.setCurrentBalance(accountBean.getBalance());
				// if(!entityTransaction.isActive()) {
				// entityTransaction.begin();
				// }
				transactionDao.addNewTransaction(t1);
				accountDao.update(accountBean);

			} else {
				// logger.error(IBSExceptionInt.INVALID_TRANS_PASSW);
				throw new IBSException(IBSExceptionInt.INVALID_TRANS_PASSW);
			}
		}
		// logger.info(" Funds transferred succesfully");
		return accountBean.getBalance();
	}

}
