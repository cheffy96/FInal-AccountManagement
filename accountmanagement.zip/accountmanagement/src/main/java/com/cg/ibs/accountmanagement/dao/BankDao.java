package com.cg.ibs.accountmanagement.dao;

import java.math.BigInteger;

import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.model.BankAdmin;

public interface BankDao {
	public BankAdmin getByAdminId(String admin_id) throws IBSException;
	public String getCustomerName(BigInteger accNo);
}
