package com.cg.ibs.accountmanagement.controller;

import java.math.BigDecimal;
import java.math.BigInteger;

public class transferFundsBean {

		private BigInteger accNo;
		private BigInteger recp_accNo;
		private BigDecimal amt;
		private String pwd;

		public transferFundsBean() {
		}

		public BigInteger getAccNo() {
			return accNo;
		}

		public void setAccNo(BigInteger accNo) {
			this.accNo = accNo;
		}

		public BigInteger getRecp_accNo() {
			return recp_accNo;
		}

		public void setRecp_accNo(BigInteger recp_accNo) {
			this.recp_accNo = recp_accNo;
		}

		public BigDecimal getAmt() {
			return amt;
		}

		public void setAmt(BigDecimal amt) {
			this.amt = amt;
		}

		public String getPwd() {
			return pwd;
		}

		public void setPwd(String pwd) {
			this.pwd = pwd;
		}
}
