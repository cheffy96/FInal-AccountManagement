package com.cg.ibs.accountmanagement.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.cg.ibs.accountmanagement.exception.IBSException;
import com.cg.ibs.accountmanagement.model.Account;
import com.cg.ibs.accountmanagement.model.AccountHoldingType;
import com.cg.ibs.accountmanagement.model.AccountStatus;
import com.cg.ibs.accountmanagement.model.AccountType;
import com.cg.ibs.accountmanagement.model.Beneficiary;
import com.cg.ibs.accountmanagement.model.BeneficiaryType;
import com.cg.ibs.accountmanagement.model.Customer;
import com.cg.ibs.accountmanagement.model.ServiceProvider;
import com.cg.ibs.accountmanagement.model.TransactionBean;
import com.cg.ibs.accountmanagement.service.AccountService;
import com.cg.ibs.accountmanagement.service.CustomerService;
import com.cg.ibs.accountmanagement.service.TransactionService;

@RequestMapping("/customer")
@RestController
@Scope("session")
@CrossOrigin
public class CustomerController {

	private DateTimeFormatter customFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy 'at' hh:mm a");
	@Autowired
	AccountService accountService;
	@Autowired
	CustomerService customerService;
	@Autowired
	TransactionService transactionService;
	String userId = "noinput";
	BigInteger clsAccNo = new BigInteger("0");
	BigInteger credAccNo = new BigInteger("0");
	Customer custbean = null;
	String message = "error";
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	
	

	@RequestMapping(value = "errors", method = RequestMethod.GET)
	public String showErrorMessage() {
		return "pageNotFound";
	}

	@GetMapping("/login/{userId}")
	public ResponseEntity<Customer> checkUser(@PathVariable("userId") String userId) throws IBSException {
		ResponseEntity<Customer> result=null;
		boolean flag = false;
		//if (userId == null) {
			//result = new ResponseEntity<>("No User Details Received", HttpStatus.BAD_REQUEST);
		//} else {
			flag = customerService.validateCustomer(userId);
			if (flag == true) {
				custbean = customerService.customerByUserId(userId);
				//String uci = custbean.getUci().toString();
				result = new ResponseEntity<Customer>(custbean, HttpStatus.OK);
			}
	//	}
		return result;
	}
	
	@ExceptionHandler(IBSException.class)
	public ResponseEntity<String> handleIBSException(IBSException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	

	@GetMapping("/balanceCheck/{uci}")
	public ResponseEntity<List<Account>> selectAccount(@PathVariable("uci") BigInteger uci) {
		ResponseEntity<List<Account>> result = null;
		if(uci==null)
		{
			result=new ResponseEntity<List<Account>>(HttpStatus.BAD_REQUEST);
		}
		else {
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccStatus().equals(AccountStatus.ACTIVE)) {
				accountsList1.add(a);
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		
		if(result==null) {
			result=new ResponseEntity<List<Account>>(HttpStatus.NO_CONTENT);
		}
		}
		return result;
	}

	@GetMapping("/bal1/{accNo}")
	public ResponseEntity<String> checkBalance(@PathVariable("accNo") BigInteger accNo) {
		BigDecimal bal = new BigDecimal(0);
		ResponseEntity<String> result = null;
		if (accNo == null) {
			result = new ResponseEntity<>("No User Details Received", HttpStatus.BAD_REQUEST);
		} else {
			try {
				bal = accountService.getBalance(accNo);
				bal = bal.setScale(2, BigDecimal.ROUND_HALF_UP);
				result = new ResponseEntity<String>(bal.toString(), HttpStatus.OK);
			} catch (IBSException e) {
				message = e.getMessage();
				result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
				// mv.addObject("message", message);
				// mv.setViewName("showMessage");
			}
		}
		return result;
	}

	@GetMapping("/miniStmts/{uci}")
	public ResponseEntity<List<Account>> selectAccount1(@PathVariable("uci") BigInteger uci) {
		ResponseEntity<List<Account>> result = null;
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccStatus().equals(AccountStatus.ACTIVE)) {
				accountsList1.add(a);
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		// mv.addObject("res", accountsList);
		// mv.setViewName("accList1");
		return result;
	}

	@GetMapping("/mini/{accNo}")
	public ResponseEntity<List<TransactionBean>> miniStatements(@PathVariable("accNo") BigInteger accNo) {
		ResponseEntity<List<TransactionBean>> result = null;
		List<TransactionBean> txns = transactionService.getMiniStmt(accNo);
		List<TransactionBean> txns_sub = null;
		int length = txns.size();
		if (length <= 10) {
			txns_sub = txns;
		} else {
			txns_sub = txns.subList(0, 10);
		}
		DateTimeFormatter dtFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a");
		result = new ResponseEntity<List<TransactionBean>>(txns_sub, HttpStatus.OK);
		// mv.addObject("dtFormat",dtFormat);
		// mv.addObject("res", txns_sub);
		// mv.setViewName("ministmt");
		return result;
	}

	@GetMapping("/periodicStmts/{uci}")
	public ResponseEntity<List<Account>> selectAccount2(@PathVariable("uci") BigInteger uci) {
		ResponseEntity<List<Account>> result = null;
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccStatus().equals(AccountStatus.ACTIVE)) {
				accountsList1.add(a);
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		// mv.addObject("res", accountsList);
		// mv.setViewName("accList1");
		return result;

	}

	@GetMapping("/periodic/{accNo}/{start}/{end}")
	public ResponseEntity<List<TransactionBean>> periodicStatements(@PathVariable("accNo") BigInteger accNo,
			@PathVariable("start") String start, @PathVariable("end") String end) {
		ResponseEntity<List<TransactionBean>> result = null;
		List<TransactionBean> txns = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH:mm:ss");
		String start1 = start;
		String end1 = end;
		start = start + "-00:00:00";
		LocalDateTime startDate1 = LocalDateTime.parse(start, formatter);
		end = end + "-23:59:59";
		LocalDateTime endDate1 = LocalDateTime.parse(end, formatter);
		long noOfDaysBetween = ChronoUnit.DAYS.between(startDate1, endDate1);
		int months = (int) (noOfDaysBetween / 30);
		DateTimeFormatter dtFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a");
		try {
			txns = transactionService.getPeriodicStmt(startDate1, endDate1, accNo);
			result = new ResponseEntity<List<TransactionBean>>(txns, HttpStatus.OK);
		} catch (IBSException e) {
			message = e.getMessage();
		}
		return result;
	}

	@GetMapping("/transferFunds/{uci}")
	public ResponseEntity<List<Account>> selectAccount3(@PathVariable("uci") BigInteger uci) {

		ResponseEntity<List<Account>> result = null;
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccType().equals(AccountType.SAVINGS)) {
				accountsList1.add(a);
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		// mv.addObject("res", accountsList1);
		// mv.setViewName("accList3");
		return result;
	}

	@PostMapping("/transfer")
	public ResponseEntity<String> transferFunds(@RequestBody transferFundsBean tf) throws IBSException {
		ResponseEntity<String> result = null;
		BigDecimal balance = new BigDecimal(-1);
		BigInteger accNo = tf.getAccNo();
		BigInteger recp_accno = tf.getRecp_accNo();
		Beneficiary bnry= customerService.selectBeneficiary(recp_accno);
		String bank= bnry.getType().toString();
		BigDecimal amt = tf.getAmt();
		String pwd = tf.getPwd();
		System.out.println(bank);
		
		if (bank.equals("MY_ACCOUNT_IN_IBS") || bank.equals("OTHERS_ACCOUNT_IN_IBS")) {
			//try {
				if (accountService.checkAccountExists(recp_accno)) {
					if (!accNo.equals(recp_accno)) {
						balance = transactionService.TransferFunds(accNo, amt, pwd, recp_accno);
						result = new ResponseEntity<String>( balance.toString(), HttpStatus.OK);
					} else {
						message = "Enter correct recipient account number";
						result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
					}
				} else {
					message = "No account exists in IBS with this account number";
					result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
				}
			//} c/atch (IBSException e) {
				// TODO Auto-generated catch block
				//message = e.getMessage();
				//result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
			//}

		} else {
			//try {
				balance = transactionService.TransferFundsOtherBank(accNo, amt, pwd, recp_accno, bank);
				result = new ResponseEntity<String>( balance.toString(), HttpStatus.OK);

			//} catch (IBSException e) {
				//message = e.getMessage();
				//result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
			//}

		}

		return result;
	}

	@GetMapping("/closeAccount1/{uci}")
	public ResponseEntity<List<Account>> selectAccount4(@PathVariable("uci") BigInteger uci) {

		ResponseEntity<List<Account>> result = null;
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccType().equals(AccountType.SAVINGS)) {
				if (a.getAccStatus().equals(AccountStatus.ACTIVE)) {
					accountsList1.add(a);
				}
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		// mv.addObject("res", accountsList1);
		// mv.setViewName("accList3");
		return result;
	}

	@GetMapping("/closeAccount2/{uci}")
	public ResponseEntity<List<Account>> selectAccount5(@PathVariable("uci") BigInteger uci) {

		ResponseEntity<List<Account>> result = null;
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccType().equals(AccountType.FIXED_DEPOSIT)
					|| a.getAccType().equals(AccountType.RECURRING_DEPOSIT)) {
				if (a.getAccStatus().equals(AccountStatus.ACTIVE)) {
					accountsList1.add(a);
				}
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		// mv.addObject("res", accountsList1);
		// mv.setViewName("accList3");
		return result;
	}

	@GetMapping("/close/{close_accNo}/{credit_accNo}")
	public ResponseEntity<String> closeAccount(@PathVariable("close_accNo") BigInteger close_accNo,
			@PathVariable("credit_accNo") BigInteger credit_accNo) {
		ResponseEntity<String> result = null;
		// clsAccNo = close_accNo;
		// credAccNo = credit_accNo;
		// ModelAndView mv = new ModelAndView();
		Account closingAccountBean = new Account();
		try {
			closingAccountBean = accountService.viewAccount(close_accNo);
			LocalDate today = LocalDate.now();
			LocalDate creationDate = closingAccountBean.getAccCreationDate();
			long noOfDaysBetween = ChronoUnit.DAYS.between(creationDate, today);
			double years = noOfDaysBetween / 365.0;
			double tenure = closingAccountBean.getTenure();
			double invAmt = closingAccountBean.getOpenBalance().doubleValue();
			double penality = 0.01 * invAmt;
			if (tenure > years) {
				result = new ResponseEntity<String>(String.valueOf(penality),
						HttpStatus.OK);
				// mv.addObject("res", penality);
				// mv.setViewName("closing");
			}

			else {
				result = new ResponseEntity<String>("Penality is :Rs.0.0  Do you want to continue?", HttpStatus.OK);
				// mv.addObject("res", "0.0");
				// mv.setViewName("closing");
			}

		} catch (IBSException e) {
			message = e.getMessage();
			result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
			// mv.addObject("message", message);
			// mv.setViewName("showMessage");
		}

		return result;
	}

	@GetMapping("/closeFinal/{close_accNo}/{credit_accNo}")
	public ResponseEntity<String> closeAccountFinal(@PathVariable("close_accNo") BigInteger close_accNo,
			@PathVariable("credit_accNo") BigInteger credit_accNo) {
		// ModelAndView mv = new ModelAndView();
		ResponseEntity<String> result = null;
		try {
			Account closingAccount = accountService.viewAccount(close_accNo);
			Account creditAccountBean = accountService.viewAccount(credit_accNo);

			creditAccountBean = accountService.closeAccount(close_accNo, credit_accNo);
			result = new ResponseEntity<String>(creditAccountBean.getBalance().toString(),
					HttpStatus.OK);
			// mv.addObject("res", creditAccountBean);
			// mv.setViewName("closingFinal");

		} catch (Exception excp) {
			// mv.addObject("result", "wrong");
			// mv.setViewName("showMessage");
			message = excp.getMessage();
			result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
		}
		return result;
	}

	@GetMapping("/openAccount/{uci}")
	public ResponseEntity<List<Account>> openAcc(@PathVariable("uci") BigInteger uci) {

		ResponseEntity<List<Account>> result = null;
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccType().equals(AccountType.SAVINGS)) {
				if (a.getAccStatus().equals(AccountStatus.ACTIVE)) {
					accountsList1.add(a);
				}
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		return result;
	}

	@PostMapping("/open")
	public ResponseEntity<String> open(@RequestBody openAccountBean acc) throws IBSException {

		ResponseEntity<String> result = null;
		custbean = customerService.customerByUserId(acc.getUserId());
		Account account = new Account();
		if (acc.getTenure() > 10 || acc.getTenure() <= 0) {
			result = new ResponseEntity<String>("Tenure Should be less than 10 years!!", HttpStatus.UNAUTHORIZED);
		} else {
			//try {
				account = accountService.addAccount(custbean, acc.getAccNo(), acc.getAcctype(), acc.getAmt(),
						acc.getTenure());
//				result = new ResponseEntity<String>(account.getAccType() + " Account is created with maturity amount: "
//						+ df2.format(account.getMaturityAmt()), HttpStatus.OK);
				result = new ResponseEntity<String>(df2.format(account.getMaturityAmt()).toString(), HttpStatus.OK);

//			} catch (IBSException e) {
//				message = e.getMessage();
//				result = new ResponseEntity<String>(message, HttpStatus.UNAUTHORIZED);
//			}
		}
		return result;
	}	
	
	@GetMapping("/payUtilityBills")
	public ResponseEntity<List<ServiceProvider>> selectServiceProviders() {
		ResponseEntity<List<ServiceProvider>> result;
//		ServiceProvider serviceProvider1 = new ServiceProvider();
		List<ServiceProvider> providers = transactionService.getServiceProviders();

		//Customer customerBean = customerService.customerByUserId(userId);
		//List<Account> accountsList = accountService.getAccounts(uci);
		//List<Account> accountsList1 = new ArrayList<Account>();

//		for (Account a : accountsList) {
//			if (a.getAccType().equals(AccountType.SAVINGS)) {
//				accountsList1.add(a);
//			}
//		}
		result=new ResponseEntity<List<ServiceProvider>>(providers, HttpStatus.OK);
		return result;
	}
	
	@GetMapping("/payUtilityBillsAccount/{uci}")
	public ResponseEntity<List<Account>> selectServiceProvidersAcc(@PathVariable("uci") BigInteger uci) {
		ResponseEntity<List<Account>> result;
		//Customer customerBean = customerService.customerByUserId(userId);
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();

		for (Account a : accountsList) {
		if (a.getAccType().equals(AccountType.SAVINGS)) {
				accountsList1.add(a);
		}
	}
		result=new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		return result;
	}

//	@RequestMapping("/payUtility")
//	public ModelAndView payUtilityBill(@RequestParam("accno") BigInteger accNo, @RequestParam("amt") BigDecimal amt,
//			@RequestParam("pwd") String pwd) {
//		ModelAndView mv = new ModelAndView();
//		BigInteger big = new BigInteger("999999");
//		try {
//			transactionService.payUtilityBill(accNo, big, pwd, amt);
//			mv.addObject("res", "Amount transferred successfully");
//			mv.setViewName("utility");
//
//		} catch (IBSException e) {
//			message = e.getMessage();
//			mv.addObject("message", message);
//			mv.setViewName("showMessage");
//
//		}
//		return mv;
//	}

	@GetMapping("/payUtility/{spaccNo}/{accNo}/{amt}/{pwd}")
	public ResponseEntity<String> payUtilityBill(@PathVariable("spaccNo") BigInteger spaccNo, @PathVariable("accNo") BigInteger accNo,@PathVariable("amt") BigDecimal amt,@PathVariable("pwd") String pwd) throws IBSException {
		BigInteger big = new BigInteger("999999");
		BigDecimal bal = new BigDecimal(0);
		ResponseEntity<String> result=null;
		if(accNo==null) {
			result = new ResponseEntity<>("No User Details Received",HttpStatus.BAD_REQUEST);
		}
		else {
		//try {
			bal = transactionService.payUtilityBill(accNo,big,pwd,amt);
			bal = bal.setScale(2, BigDecimal.ROUND_HALF_UP);
			result=new ResponseEntity<String>(bal.toString(),HttpStatus.OK);
//		} catch (IBSException e) {
//			message = e.getMessage();
//			result=new ResponseEntity<String>(message,HttpStatus.UNAUTHORIZED);
//		}
		}
		return result ;
	}
	
	
	@GetMapping("/viewAccount/{uci}")
	public ResponseEntity<List<Account>> selectViewAccount(@PathVariable("uci") BigInteger uci) {
		ResponseEntity<List<Account>> result = null;
		List<Account> accountsList = accountService.getAccounts(uci);
		List<Account> accountsList1 = new ArrayList<Account>();
		for (Account a : accountsList) {
			if (a.getAccStatus().equals(AccountStatus.ACTIVE)) {
				accountsList1.add(a);
			}
		}
		result = new ResponseEntity<List<Account>>(accountsList1, HttpStatus.OK);
		return result;
	}

	@GetMapping("/view/{accNo}")
	public ResponseEntity<Account> viewAccount(@PathVariable("accNo") BigInteger accNo) {
		ResponseEntity<Account> result = null;
		Account account = new Account();
		try {
			account = accountService.viewAccount(accNo);
			// mv.addObject("account", account);
			// mv.setViewName("viewAccountDisplay");
			result = new ResponseEntity<Account>(account, HttpStatus.OK);

		} catch (IBSException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			message = e.getMessage();
			// mv.addObject("message", message);
			// mv.setViewName("showMessage");

		}
		return result;
	}
	@GetMapping("/viewben/{uci}")
    public ResponseEntity<List<Beneficiary>> viewBeneficiaries(@PathVariable("uci") BigInteger uci) {
        ResponseEntity<List<Beneficiary>> result = null;
        List<Beneficiary> beneficiaries;
        
        try {
            beneficiaries = customerService.getBeneficiary(uci);
            result = new ResponseEntity<List<Beneficiary>>(beneficiaries, HttpStatus.OK);
        } catch (Exception e) {
            result = new ResponseEntity<List<Beneficiary>>(HttpStatus.BAD_REQUEST);
        }
        System.out.println(result);
        return result;
    }
	
	@GetMapping("/selectben/{accNo}")
	public ResponseEntity<Beneficiary> selectBeneficiary(@PathVariable("accNo") BigInteger accNo){
		ResponseEntity<Beneficiary> result = null;
		Beneficiary beneficary=null;
		try {
			beneficary=customerService.selectBeneficiary(accNo);
			result= new ResponseEntity<Beneficiary>(beneficary, HttpStatus.OK);
		}catch(Exception e) {
			result = new ResponseEntity<Beneficiary>(HttpStatus.BAD_REQUEST);
		}
		return result;
	}

}
