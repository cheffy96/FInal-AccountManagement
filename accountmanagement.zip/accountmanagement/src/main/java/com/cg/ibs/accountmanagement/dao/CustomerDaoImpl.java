package com.cg.ibs.accountmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

//import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.accountmanagement.model.Beneficiary;
import com.cg.ibs.accountmanagement.model.Customer;


@Repository("customerDao")
public class CustomerDaoImpl implements CustomerDao {
	
	//private static Logger logger = Logger.getLogger(CustomerDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;
	
//	public CustomerDaoImpl() {
//		entityManager= DBUtil.getEntityManger();
//	}

	public Customer getCustomerByUCI(BigInteger UCI) {
		Customer customerBean = entityManager.find(Customer.class, UCI);
		//logger.info(" Customer details returned using UCI");
		return customerBean;
	}

	public Customer getCustomerByUserId(String userId) {
		Customer customerBean=null;
		TypedQuery<Customer> query = entityManager.createNamedQuery("CB_BY_UID", Customer.class);
		query.setParameter("userId", userId);
		try {
		customerBean = query.getSingleResult();}
		catch(NoResultException e){	
		}
		//logger.info(" Customer details returned using userId");
		return customerBean;
	}

	@Override
	public List<Beneficiary> getBeneficiary(BigInteger uci) {
		List<Beneficiary> beneficiarySet=null;
		TypedQuery<Beneficiary> query = entityManager.createNamedQuery("GET_BENEFICIARY",Beneficiary.class);
		query.setParameter("uci", uci);
		try {
			beneficiarySet = query.getResultList();
		}
		catch(Exception e) {
			
		}
		return beneficiarySet;
	}

	@Override
	public Beneficiary beneficiary(BigInteger accNo) {
		Beneficiary beneficiary= entityManager.find(Beneficiary.class, accNo);
		return beneficiary;
	}


}
