import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenRDComponent } from './open-rd.component';

describe('OpenRDComponent', () => {
  let component: OpenRDComponent;
  let fixture: ComponentFixture<OpenRDComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpenRDComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenRDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
