import { Component, OnInit } from '@angular/core';
import { OpenAccount } from '../model/open-account.model';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-open-rd',
  templateUrl: './open-rd.component.html',
  styleUrls: ['./open-rd.component.css']
})
export class OpenRDComponent implements OnInit {
  account: Account[];
  accNo1: number;
 openacct:OpenAccount;
 rdamt: number;
 rdtenure: number;
result: string;
errmsg:string;
  constructor(private accService: AccountService, private router: Router) {
    this.account=[];
    this.openacct= new OpenAccount();
   }

  ngOnInit() {
    
    this.accService.getSavingsAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
        
      }
    );

  }

  rd(){
    this.errmsg ="";
    console.log(JSON.stringify(this.openacct));
    this.openacct.accNo=this.accNo1;
    this.openacct.acctype="RECURRING_DEPOSIT";
    this.openacct.amt=this.rdamt;
    this.openacct.tenure=this.rdtenure;
    this.openacct.userId=this.accService.userid;
    this.accService.fd(this.openacct).subscribe(
      
        (data) => {
          this.result = data;
        
      },(error) =>{
        this.errmsg = error;
      }
    )
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }
}
