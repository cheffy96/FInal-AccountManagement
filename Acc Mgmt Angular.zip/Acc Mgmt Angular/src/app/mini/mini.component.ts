import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { Transaction } from '../model/transaction.model';

@Component({
  selector: 'app-mini',
  templateUrl: './mini.component.html',
  styleUrls: ['./mini.component.css']
})
export class MiniComponent implements OnInit {

  account: Account[];
  accNo1: number;
  transactions: Transaction[];

  constructor(private accService: AccountService, private router: Router) { 
    this.account = [];
  }

  ngOnInit() {

    this.accService.getSavingsAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
        console.log(this.account);
      }
    );

  }
  mini(){
    this.accService.getMini(this.accNo1).subscribe(
      (data) => {
        this.transactions = data;
      }
    )
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }
}
