import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable ,throwError} from 'rxjs';
import { TransferFunds } from '../model/transfer-funds.model';
import { OpenAccount } from '../model/open-account.model';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
errormsg:string;
  baseUrl: string;
  uci : number;
  userid: string;
  firstname: string;
  lastname: string;
  constructor(private http: HttpClient) { 
    this.baseUrl = `${environment.baseMwUrl}/customer`;
  }

  getAllAccounts(UCI: number):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/balanceCheck/${UCI}`).pipe(catchError(this.errorHandler));
  }

  getBalance(accNo: number): Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/bal1/${accNo}`).pipe(catchError(this.errorHandler))
  }
  
  getSavingsAccounts(UCI: number):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/transferFunds/${UCI}`).pipe(catchError(this.errorHandler));
  }
  
  getBenificiaryAccounts(UCI: number):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/viewben/${UCI}`).pipe(catchError(this.errorHandler));
  }

  transferFunds(transfer: TransferFunds):Observable<any>{
    return this.http.post<any>(`${this.baseUrl}/transfer`,transfer).pipe(catchError(this.errorHandler));
  }

  getMini(accNo: number): Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/mini/${accNo}`).pipe(catchError(this.errorHandler));
  }

  fd(openacct: OpenAccount):Observable<any>{
    return this.http.post<any>(`${this.baseUrl}/open`, openacct).pipe(catchError(this.errorHandler));
  }
  view(accNo:number):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/view/${accNo}`).pipe(catchError(this.errorHandler));
  }
  getFRAccounts(UCI: number):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/closeAccount2/${UCI}`).pipe(catchError(this.errorHandler));
  }
  close(accNo1:number,accNo3:number):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/close/${accNo1}/${accNo3}`).pipe(catchError(this.errorHandler));
  }
  finalClose(accNo1:number,accNo3:number):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/closeFinal/${accNo1}/${accNo3}`).pipe(catchError(this.errorHandler));
  }
  getSPList():Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/payUtilityBills/`).pipe(catchError(this.errorHandler));
  }

  payUtilityBills(accNo3:number,accNo1:number,amt:number,pwd:string):Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/payUtility/${accNo3}/${accNo1}/${amt}/${pwd}`).pipe(catchError(this.errorHandler));
  }
 
  errorHandler(error:HttpErrorResponse){
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      this.errormsg=error.error;
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
     this.errormsg);
  
  }
}
