import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  baseUrl: string;

  constructor(private http: HttpClient) { 
    this.baseUrl = `${environment.baseMwUrl}/banker`;
  }

  bankLogin(adminId:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/bankerlogin/${adminId}`, {responseType:'text'});
  }

  getAccount(accNo:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/getAccount/${accNo}`);
  }

  fundsDeposit(accNo:string, amount: number):Observable<any>{
    return this.http.get(`${this.baseUrl}/depositDone/${amount}/${accNo}`,{responseType:'text'});
  }
  
  periodicStatement(accNo:string, startDate:Date, endDate:Date):Observable<any>{
    return this.http.get(`${this.baseUrl}/periodicFinal/${accNo}/${startDate}/${endDate}`);
  }
}
