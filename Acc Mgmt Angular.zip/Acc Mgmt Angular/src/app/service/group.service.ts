import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Group } from '../model/group';

@Injectable({
  providedIn: 'root'
})
export class GroupService {

  baseUrl:string;

  constructor(private http:HttpClient) {
    this.baseUrl=`${environment.baseMwUrl}/group`;
  }

  getAll():Observable<Group[]>{
    return this.http.get<Group[]>(this.baseUrl);
  }

  getById(id:number):Observable<Group>{
    return this.http.get<Group>(`${this.baseUrl}/${id}`);
  }

  add(group:Group):Observable<Group>{
    return this.http.post<Group>(this.baseUrl,group);
  }
  
  update(group:Group):Observable<Group>{
    return this.http.put<Group>(this.baseUrl,group);
  }
  
  deleteById(id:number):Observable<any>{
    return this.http.delete<any>(`${this.baseUrl}/${id}`);
  }

}
