import { Component, OnInit } from '@angular/core';
import { BankService } from '../service/bank.service';

@Component({
  selector: 'app-periodic-statement',
  templateUrl: './periodic-statement.component.html',
  styleUrls: ['./periodic-statement.component.css']
})
export class PeriodicStatementComponent implements OnInit {
  accNo:string;
  accountMap:Map<string,Account>;
  startDate1: Date;
  endDate1: Date;
  transactions: any;
  today: Date;
  constructor(private bankService:BankService) {
    this.today= new Date();
   }

  ngOnInit() {
  }
  getAccount(){
    this.bankService.getAccount(this.accNo).subscribe(
      (data)=>{
        this.accountMap=data;
      }
    )
  }

  // convertToDate(val){
  //   return Date(val);
  // }
  getStatement(){
    if(this.checkDate())
    {this.bankService.periodicStatement(this.accNo,this.startDate1,this.endDate1).subscribe(
      (data)=>{
        this.transactions=data;

        console.log(this.transactions);
      }
    
    )
    }
  }

  checkDate(){
    if(this.endDate1<this.startDate1){
      alert(" Start Date can't be greater than the End Date ")
      return false;
    }
    if(this.endDate1>this.today || this.startDate1>this.today){
      alert(" Date can't be greater than the current Date ")
      return false;
    }
    else
    return true;
  }
 
}
