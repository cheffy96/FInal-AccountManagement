import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { BankerListComponent } from './banker-list/banker-list.component';
import { CustLoginComponent } from './cust-login/cust-login.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { BalanceComponent } from './balance/balance.component';
import { TransferComponent } from './transfer/transfer.component';
import { PeriodicComponent } from './periodic/periodic.component';
import { MiniComponent } from './mini/mini.component';
import { OpenFDComponent } from './open-fd/open-fd.component';
import { OpenRDComponent } from './open-rd/open-rd.component';
import { ViewComponent } from './view/view.component';
import { CloseComponent } from './close/close.component';
import { BankerLoginComponent } from './banker-login/banker-login.component';
import { FundsDepositComponent } from './funds-deposit/funds-deposit.component';
import { PeriodicStatementComponent } from './periodic-statement/periodic-statement.component';
import { BalanceCheckComponent } from './balance-check/balance-check.component';

import { PayUtilityComponent } from './pay-utility/pay-utility.component';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
   CustomerListComponent,
    BankerListComponent,
    BankerLoginComponent,
    FundsDepositComponent,
    PeriodicStatementComponent,
    BalanceCheckComponent,
    CustLoginComponent,
    LoginpageComponent,
    BalanceComponent,
    TransferComponent,
    PeriodicComponent,
    MiniComponent,
    OpenFDComponent,
    OpenRDComponent,
    ViewComponent,
    CloseComponent,
    PayUtilityComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
