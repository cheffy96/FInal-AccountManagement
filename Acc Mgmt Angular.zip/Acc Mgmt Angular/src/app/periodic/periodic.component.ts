import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Transaction } from '../model/transaction.model';
import { Router } from '@angular/router';
import { BankService } from '../service/bank.service';

@Component({
  selector: 'app-periodic',
  templateUrl: './periodic.component.html',
  styleUrls: ['./periodic.component.css']
})
export class PeriodicComponent implements OnInit {
  account: Account[];
  accNo1: number;
  transactions: Transaction[];
  endDate1:Date;
  startDate1:Date;
  today:Date;
  constructor(private accService: AccountService, private router: Router, private bankService: BankService) { 
    this.account = [];
    this.today= new Date();
  }

  ngOnInit() {
    this.accService.getSavingsAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
        console.log(this.account);
      }
    );
  }

  getStatement(){
    if(this.checkDate())
    {this.bankService.periodicStatement(this.accNo1.toString(),this.startDate1,this.endDate1).subscribe(
      (data)=>{
        this.transactions=data;

        console.log(this.transactions);
      }
    
    )
    }
  }

  checkDate(){
    if(this.endDate1<this.startDate1){
      alert(" Start Date can't be greater than the End Date ")
      return false;
    }
    if(this.endDate1>this.today || this.startDate1>this.today){
      alert(" Date can't be greater than the current Date ")
      return false;
    }
    else
    return true;
  }

  goback(){
    this.router.navigate(['/customer-list'])
  }
}
