import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { Account } from '../model/account.model';

@Component({
  selector: 'app-close',
  templateUrl: './close.component.html',
  styleUrls: ['./close.component.css']
})
export class CloseComponent implements OnInit {

  closeAccount: Account[];
  creditAccount: Account[];
  accNo1: number;
  accNo3: number;
  penality: string;
  currentBalance: number;

  constructor(private accService: AccountService, private router: Router) {
    this.closeAccount = [];
    this.creditAccount = []; 

  }

  ngOnInit() {
    this.accService.getSavingsAccounts(this.accService.uci).subscribe(
      (data) => {
        this.creditAccount = data;
      }
    );

    this.accService.getFRAccounts(this.accService.uci).subscribe(
      (data) => {
        this.closeAccount = data;
      }
    );
  }

  close(){
    this.accService.close(this.accNo1,this.accNo3).subscribe(
      (data) => {
        this.penality = data;

      }
    )
  }
  finalClose(){
    this.accService.finalClose(this.accNo1,this.accNo3).subscribe(
      (data) => {
        this.currentBalance = data;


      }
    )
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }
}
