import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';



import { from } from 'rxjs';
import { CustLoginComponent } from './cust-login/cust-login.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { BalanceComponent } from './balance/balance.component';
import { TransferComponent } from './transfer/transfer.component';
import { MiniComponent } from './mini/mini.component';
import { OpenFDComponent } from './open-fd/open-fd.component';
import { OpenRDComponent } from './open-rd/open-rd.component';
import { ViewComponent } from './view/view.component';
import { CloseComponent } from './close/close.component';
import { PayUtilityComponent } from './pay-utility/pay-utility.component';
import { FundsDepositComponent } from './funds-deposit/funds-deposit.component';
import { BankerLoginComponent } from './banker-login/banker-login.component';
import { BankerListComponent } from './banker-list/banker-list.component';
import { PeriodicStatementComponent } from './periodic-statement/periodic-statement.component';
import { BalanceCheckComponent } from './balance-check/balance-check.component';
import { PeriodicComponent } from './periodic/periodic.component';


const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'custLogin',component:CustLoginComponent},
  {path:'customer-list/balance',component:BalanceComponent},
  {path:'customer-list/transfer',component:TransferComponent},
  {path:'customer-list/mini',component:MiniComponent},
  {path:'customer-list/openFD',component:OpenFDComponent},
  {path:'customer-list/openRD',component:OpenRDComponent},
  {path:'customer-list/view',component:ViewComponent},
  {path:'customer-list/close',component:CloseComponent},
  {path:'customer-list/pay-utility',component:PayUtilityComponent},
  {path:'customer-list/periodicStatement',component:PeriodicComponent},
  {path:'funds-deposit', component:FundsDepositComponent},
  {path:'bankLogin', component:BankerLoginComponent},
  {path:'bankerList', component:BankerListComponent},
  {path:'periodicStatement', component:PeriodicStatementComponent},
  {path:'balance-check', component:BalanceCheckComponent},
  {path:'customer-list',component:CustomerListComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
