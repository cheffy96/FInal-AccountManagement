import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundsDepositComponent } from './funds-deposit.component';

describe('FundsDepositComponent', () => {
  let component: FundsDepositComponent;
  let fixture: ComponentFixture<FundsDepositComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundsDepositComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundsDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
