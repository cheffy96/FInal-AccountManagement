import { Component, OnInit } from '@angular/core';
import { BankService } from '../service/bank.service';
import { Account } from '../model/account.model';

@Component({
  selector: 'app-funds-deposit',
  templateUrl: './funds-deposit.component.html',
  styleUrls: ['./funds-deposit.component.css']
})
export class FundsDepositComponent{
  accNo:string;
  accountMap:Map<string,Account>;
  amount:number;
  message:string;

  constructor(private bankService:BankService) { 
    this.accNo= "";
  }

  ngOnInit() {
  }

  getAccount(){
    this.bankService.getAccount(this.accNo).subscribe(
      (data)=>{
        this.accountMap=data;
      }
    )
  }

  fundsDeposit(){
    this.bankService.fundsDeposit(this.accNo,this.amount).subscribe(
      (data)=>{
        this.message=data;
      }
    )
  }
  convertToInt(val){
    return parseInt(val);
  }
}
