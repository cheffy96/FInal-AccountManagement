import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { Account } from '../model/account.model';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  account: Account[];
  account1: Account;
  accNo1: number;


  constructor(private accService: AccountService, private router: Router) {
    this.account= [];
       }

  ngOnInit() {

    this.accService.getAllAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
      }
    );
   
  }

  view(){
    this.account1 = new Account();
    this.accService.view(this.accNo1).subscribe(
      (data) => {
        this.account1 = data;
      }
    )
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }
}
