import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {

  firstname: string;
  lastname:string;
  constructor(private custService:CustomerService,private accService : AccountService, private router:Router) { 
    this.firstname=accService.firstname;
    this.lastname=accService.lastname;
  }

  ngOnInit() {
  }

}
