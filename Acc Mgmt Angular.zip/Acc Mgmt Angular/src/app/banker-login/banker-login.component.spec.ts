import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankerLoginComponent } from './banker-login.component';

describe('BankerLoginComponent', () => {
  let component: BankerLoginComponent;
  let fixture: ComponentFixture<BankerLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankerLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankerLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
