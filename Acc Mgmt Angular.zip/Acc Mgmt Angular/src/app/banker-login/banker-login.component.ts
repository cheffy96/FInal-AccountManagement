import { Component} from '@angular/core';
import { BankService } from '../service/bank.service';
import { Router} from "@angular/router";

@Component({
  selector: 'app-banker-login',
  templateUrl: './banker-login.component.html',
  styleUrls: ['./banker-login.component.css']
})
export class BankerLoginComponent{
  adminId:string;
  message:string;

  constructor(private bankService:BankService, private router:Router) {
    this.adminId= "";
   }

  ngOnInit() {
  }

  load(){

  }

  bankLogin(){
  this.bankService.bankLogin(this.adminId).subscribe(
    (data)=>{
      this.message=data;
      // localStorage.setItem('msg',JSON.stringify(this.message));
      // console.log(this.message);
      // this.load();
      this.router.navigateByUrl("/bankerList");
    }
  )
  }
}
