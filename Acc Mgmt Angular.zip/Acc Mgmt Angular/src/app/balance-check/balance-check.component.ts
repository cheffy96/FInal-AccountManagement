import { Component, OnInit } from '@angular/core';
import { BankService } from '../service/bank.service';

@Component({
  selector: 'app-balance-check',
  templateUrl: './balance-check.component.html',
  styleUrls: ['./balance-check.component.css']
})
export class BalanceCheckComponent implements OnInit {
  accNo:string;
  accountMap:Map<string,Account>;
  constructor(private bankService:BankService) { }

  ngOnInit() {
  }
  getAccount(){
    this.bankService.getAccount(this.accNo).subscribe(
      (data)=>{
        this.accountMap=data;
      }
    )
  }
}
