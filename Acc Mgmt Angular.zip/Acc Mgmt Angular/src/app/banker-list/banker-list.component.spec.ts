import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankerListComponent } from './banker-list.component';

describe('BankerListComponent', () => {
  let component: BankerListComponent;
  let fixture: ComponentFixture<BankerListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankerListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
