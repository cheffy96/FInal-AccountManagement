import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banker-list',
  templateUrl: './banker-list.component.html',
  styleUrls: ['./banker-list.component.css']
})
export class BankerListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
