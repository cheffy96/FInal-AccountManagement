import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { Account } from '../model/account.model';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {
  account: Account[];
  public balance: string;
  public Origins: number;

  constructor(private accService: AccountService, private router: Router) {
    this.account = [];
  }

  ngOnInit() {

    this.accService.getAllAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
      }
    );
    

  }

  getBalance() {
    this.accService.getBalance(this.Origins).subscribe(
      (data) =>{
        this.balance = data;
      }
    )
    
    
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }

}
