import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { ServiceProviders } from '../model/service-providers.model';
import { PaySP } from '../model/pay-sp.model';

@Component({
  selector: 'app-pay-utility',
  templateUrl: './pay-utility.component.html',
  styleUrls: ['./pay-utility.component.css']
})
export class PayUtilityComponent implements OnInit {
  account: Account[];
  accNo1: number;
  spList: ServiceProviders[];
  accNo3: number;
  pwd:string;
  amt:number;
  payspmodel: PaySP;
  result:string;
  errmsg:string;

  constructor(private accService: AccountService, private router: Router) { 
    this.account=[];
    this.spList=[];
    this.payspmodel= new PaySP();
  }

  ngOnInit() {
    this.accService.getSavingsAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
      }
    );
    this.accService.getSPList().subscribe(
      (data) => {
        this.spList = data;
      }
    );
  }

  payUtilityBills(){
    this.errmsg = "";
//this.payspmodel.accNo=this.accNo1;
//this.payspmodel.spaccNo=this.accNo3;
//this.payspmodel.pwd=this.pwd;
//this.payspmodel.amt=this.amt;
this.accService.payUtilityBills(this.accNo3,this.accNo1,this.amt,this.pwd).subscribe(
  (data) => {
    this.result = data;
  },(error) => {
    this.errmsg = error;
  }
);
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }
}
