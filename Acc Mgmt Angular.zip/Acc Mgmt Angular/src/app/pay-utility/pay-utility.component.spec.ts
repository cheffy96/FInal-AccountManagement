import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayUtilityComponent } from './pay-utility.component';

describe('PayUtilityComponent', () => {
  let component: PayUtilityComponent;
  let fixture: ComponentFixture<PayUtilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayUtilityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayUtilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
