import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { Account } from '../model/account.model';
import { Beneficiary } from '../model/beneficiary.model';
import { TransferFunds }  from '../model/transfer-funds.model'

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {
  account: Account[];
  beneficiary: Beneficiary[];
  tranfermodel: TransferFunds;
  balance: string;
  amt:number;
  pwd:string;
  accNo1:number;
  accNo2:number;
  errmsg: string;
  
  constructor(private accService: AccountService, private router: Router) {
    this.account = [];
    this.beneficiary = [];
    this.tranfermodel= new TransferFunds();
  }

  ngOnInit() {
    this.accService.getSavingsAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
      }
    );

    this.accService.getBenificiaryAccounts(this.accService.uci).subscribe(
      (data) => {
        this.beneficiary = data;
      }
    );
   
  }

  transferfund(){
    this.errmsg ="";
    this.tranfermodel.accNo=this.accNo2;
    this.tranfermodel.recp_accNo=this.accNo1;
    this.tranfermodel.pwd=this.pwd;
    this.tranfermodel.amt=this.amt;
    this.accService.transferFunds(this.tranfermodel).subscribe(
      (data) =>{
        this.balance=data;

      },(error) => {
        this.errmsg = error;


      }

    );
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }

}
