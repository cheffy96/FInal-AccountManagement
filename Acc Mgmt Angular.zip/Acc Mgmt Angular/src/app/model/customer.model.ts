export class Customer {
    public uci: number;
    public userId: string;
    public firstName: string;
    public lastname: string;
}
