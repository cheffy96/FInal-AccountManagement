import { ServiceProviders } from './service-providers.model';

describe('ServiceProviders', () => {
  it('should create an instance', () => {
    expect(new ServiceProviders()).toBeTruthy();
  });
});
