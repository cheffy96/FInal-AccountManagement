import { PaySP } from './pay-sp.model';

describe('PaySP', () => {
  it('should create an instance', () => {
    expect(new PaySP()).toBeTruthy();
  });
});
