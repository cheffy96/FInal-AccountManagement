export class Account {
    public accNo: number;
    public balance: number;
    public transac_pass: string;
    public accCreationDate: Date;
    public accType: string;
    public tenure: number;
    public maturityAmt: number;

}
