import { TransferFunds } from './transfer-funds.model';

describe('TransferFunds', () => {
  it('should create an instance', () => {
    expect(new TransferFunds()).toBeTruthy();
  });
});
