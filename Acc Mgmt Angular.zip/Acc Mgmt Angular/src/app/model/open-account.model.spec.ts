import { OpenAccount } from './open-account.model';

describe('OpenAccount', () => {
  it('should create an instance', () => {
    expect(new OpenAccount()).toBeTruthy();
  });
});
