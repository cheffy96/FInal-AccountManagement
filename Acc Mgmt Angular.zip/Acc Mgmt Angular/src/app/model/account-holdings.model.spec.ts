import { AccountHoldings } from './account-holdings.model';

describe('AccountHoldings', () => {
  it('should create an instance', () => {
    expect(new AccountHoldings()).toBeTruthy();
  });
});
