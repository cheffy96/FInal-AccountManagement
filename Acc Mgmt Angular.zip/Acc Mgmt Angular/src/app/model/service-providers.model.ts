export class ServiceProviders {
    public nameOfCompany: string;
    public accountNumber: number;
    public category: string;
}
