export class PaySP {
    public spaccNo : number;
    public accNo: number;
    public amt: number;
    public pwd: string;
}
