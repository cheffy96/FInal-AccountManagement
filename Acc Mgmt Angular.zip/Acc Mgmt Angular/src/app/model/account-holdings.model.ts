export class AccountHoldings {
    public aHId:number;
    
}
