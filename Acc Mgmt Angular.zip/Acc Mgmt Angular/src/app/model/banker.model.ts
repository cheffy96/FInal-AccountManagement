export class Banker {
    public username: string;
}
