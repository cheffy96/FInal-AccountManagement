export class OpenAccount {
    public acctype: string;
    public accNo: number;
    public amt: number;
    public tenure: number;
    public userId: string;
}
