export class Transaction {
    public transactionId: number;
    public transactionType: string;
    public transactionDate: Date;
    public transactionAmount: number;
    public currentBalance: number;
    public transactionMode: string;
    public transactionDescription: string;
    public referenceId: string;
}
