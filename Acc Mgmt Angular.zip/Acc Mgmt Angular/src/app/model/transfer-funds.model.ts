export class TransferFunds {
    public accNo: number;
    public recp_accNo: number;
    //public bank: string;
    public amt: number;
    public pwd: string;
    
}
