export class Beneficiary {
    public accountNumber: number;
}
