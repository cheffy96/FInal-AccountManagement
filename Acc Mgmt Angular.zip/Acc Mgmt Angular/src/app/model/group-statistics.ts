export class GroupStatistics {
    public groupName:string;
    public count:number;
}
