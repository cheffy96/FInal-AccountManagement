import { Component, OnInit } from '@angular/core';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { OpenAccount } from '../model/open-account.model';

@Component({
  selector: 'app-open-fd',
  templateUrl: './open-fd.component.html',
  styleUrls: ['./open-fd.component.css']
})
export class OpenFDComponent implements OnInit {
  account: Account[];
  accNo1: number;
 openacct:OpenAccount;
 fdamt: number;
 fdtenure: number;
result: string;
errmsg:string;
  constructor(private accService: AccountService, private router: Router) {
    this.account=[];
    this.openacct= new OpenAccount();
   }

  ngOnInit() {
    
    this.accService.getSavingsAccounts(this.accService.uci).subscribe(
      (data) => {
        this.account = data;
      }
    );

  }

  fd(){
    this.errmsg ="";
    this.openacct.accNo=this.accNo1;
    this.openacct.acctype="FIXED_DEPOSIT";
    this.openacct.amt=this.fdamt;
    this.openacct.tenure=this.fdtenure;
    this.openacct.userId=this.accService.userid;
    this.accService.fd(this.openacct).subscribe(
      
        (data) => {
          this.result = data;
        
      },(error) =>{
        this.errmsg = error;
      }
    )
  }
  goback(){
    this.router.navigate(['/customer-list'])
  }

}
