import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenFDComponent } from './open-fd.component';

describe('OpenFDComponent', () => {
  let component: OpenFDComponent;
  let fixture: ComponentFixture<OpenFDComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpenFDComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenFDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
