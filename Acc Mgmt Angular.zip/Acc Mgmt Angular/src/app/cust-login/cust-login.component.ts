import { Component} from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { AccountService } from '../service/account.service';
import { Customer } from '../model/customer.model';

@Component({
  selector: 'app-cust-login',
  templateUrl: './cust-login.component.html',
  styleUrls: ['./cust-login.component.css']
})
export class CustLoginComponent{
errmsg:string;
  userId: string;
  uci: number;
  customermodel: Customer;
  constructor(private custService:CustomerService,private accService : AccountService, private router:Router) {
    this.userId = "";
  }

  ngOnInit() {
  }

  custLogin(){
    this.errmsg ="";
    this.customermodel=new Customer();
    this.custService.custLogin(this.userId).subscribe(
      (data)=>{
        this.customermodel = data;
        this.accService.uci= +this.customermodel.uci;
        this.accService.userid=this.customermodel.userId;
        this.accService.firstname=this.customermodel.firstName;
        this.accService.lastname=this.customermodel.lastname;
        this.router.navigateByUrl("customer-list");
      },
      (error) =>{
            this.errmsg=error;
      }
);

    }

}
